# Coding-Raja-Technologies-Internship
<br>
Sentiment Analysis on Social Media Data
<br>
#Exporting The Text from whatsapp and implement it as txt file. 
